#-*- coding: utf-8 -*-

# 모듈 및 데이터 참조
import numpy
from matplotlib import pyplot
from sample import seoul
from sample import busan
from sample import daegu
from sample import inchun

# 합계 계산을 위해 데이터를 numpy 배열로 변환
v1 = numpy.array(seoul)
v2 = numpy.array(busan)
v3 = numpy.array(daegu)
v4 = numpy.array(inchun)

# 데이터는 각 지역별 교통사고 수의 월별 합계
ratio = [v1.sum(), v2.sum(), v3.sum(), v4.sum()]
# 각 항목의 라벨
labels = ['서울', '부산', '대구', '인천']
# 각 항목의 색상
colors = ['#ff6600', '#ff00ff', '#ffff00', '#00ffff']

# 한글 폰트 설정, 그래픽 크기 설정
pyplot.rcParams["font.family"] = 'NanumGothic'
pyplot.rcParams["font.size"] = 12
pyplot.rcParams["figure.figsize"] = (10, 10)

pyplot.figure()
pyplot.title('2017년 주요 도시별 교통사고 비율')
pyplot.pie(ratio, labels=labels, colors=colors, autopct='%0.2f%%', startangle=90)
pyplot.show()
pyplot.close()
