# -*- coding: utf-8 -*-
"""
test03.py
"""
# 어떤 사람의 주민번호가 801023-1000123 일 때
# 이 사람의 생년월일을 출력하는 프로그램을 작성
jumin = "801023-1000123"
yy = jumin[:2]
mm = jumin[2:4]
dd = jumin[4:6]

# 결과를 출력할 때는 문자열의 format 함수를 사용
tpl = "당신의 생일은 {0}년 {1}월 {2}일 입니다."
print(tpl.format(yy, mm, dd))
