# -*- coding: utf-8 -*-
"""
test04.py
"""
# 사진 파일의 경로를 임의의 변수에 할당
path = "C:\\myphoto\\helloworld.jpg"

# rfind() 함수를 사용하여 역슬래시가 마지막으로 나타나는 위치 조회
p1 = path.rfind("\\")

# rfind() 점(.)이 마지막으로 나타나는 위치 조회
p2 = path.rfind(".")

# 폴더의 위치 -> 처음부터 마지막 역슬래시 전까지
dir_path = path[:p1]
print(dir_path)

# 사진파일의 이름 -> 마지막 역슬래시 다음부터 점의 위치 전까지
file_name = path[p1+1:p2]
print(file_name)

# 확장자 -> 점 다음부터 끝까지
ext_name = path[p2+1:]
print(ext_name)
