# -*- coding: utf-8 -*-
"""
	test05.py
	
	[1, 2, 3, 4, 5] 라는 리스트를 [5, 4, 3, 2, 1] 로 만들어 출력하시오.
	(리스트의 순서를 뒤집는 함수를 사용해야 합니다.)
"""
# 리스트 만들고 결과 출력
mylist = [1, 2, 3, 4, 5]
print(mylist)

# 리스트를 역순으로 정렬하는 함수 사용
mylist.reverse()
print(mylist)

# [참고]
# 순차정렬
mylist.sort()
print(mylist)

# 역순정렬
mylist.sort(reverse=True)
print(mylist)