# -*- coding: utf-8 -*-
"""
	test06.py

	[ "Life", "is", "too", "short" ]라는 리스트를 
	"Life is too short"라는 문자열로 결합한 뒤 
	결합된 문자열의 모든 글자를 대문자 형태로 출력하시오.
"""
# 리스트 만들고 결과 출력
mylist = ["Life", "is", "too", "short"]
print(mylist)

# 리스트의 각 원소를 공백을 기준으로 문자열로 결합
space = " "
mystr = space.join(mylist)
print(mystr)

# 변환된 결과를 대문자로 변환
uppercase = mystr.upper()
print(uppercase)

# [참고] 문자열을 소문자로 변환
lowercase = mystr.lower()
print(lowercase)
