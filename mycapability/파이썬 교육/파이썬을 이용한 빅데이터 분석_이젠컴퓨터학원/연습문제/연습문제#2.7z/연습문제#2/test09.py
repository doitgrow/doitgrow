# -*- coding: utf-8 -*-
"""
	test09.py
	쇼핑몰의 장바구니를 표현한 딕셔너리 리스트 정의
"""

# 주어진 내용에 맞는 자료구조를 정의할 수 있는지 확인하는 문제 입니다.
cart = [
    {'price': 38000, 'qty': 6},
    {'price': 20000, 'qty': 4},
    {'price': 17900, 'qty': 3},
    {'price': 17900, 'qty': 5}
]

tpl = "{0}원 x {1}개 -> 총 {2}원"
print(tpl.format(cart[0]['price'], cart[0]['qty'],
                 cart[0]['price'] * cart[0]['qty']))
print(tpl.format(cart[1]['price'], cart[1]['qty'],
                 cart[1]['price'] * cart[1]['qty']))
print(tpl.format(cart[2]['price'], cart[2]['qty'],
                 cart[2]['price'] * cart[2]['qty']))
print(tpl.format(cart[3]['price'], cart[3]['qty'],
                 cart[3]['price'] * cart[3]['qty']))



