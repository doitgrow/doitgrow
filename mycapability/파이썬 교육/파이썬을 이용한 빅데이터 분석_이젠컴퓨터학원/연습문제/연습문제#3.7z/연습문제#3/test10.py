# -*- coding: utf-8 -*-
"""
	test10.py
"""
# 1) 자신의 키를 의미하는 변수 height와 자신의 몸무게를 의미하는 변수 weight를
#    정의하고 적절한 값을 대입하세요.
height = 175
weight = 72

# 2) 표준체중을 다음의 공식으로 구하여 standard_weight라는 변수에 대입하세요.
#		키 150 이하 -> 신장cm – 110
#		키 151 이상 -> (신장cm – 110) x 0.9
if height <= 150:
    standard_weight = height - 110
else:
    standard_weight = (height - 110) * 0.9

# 비만도 값 obesity를 다음의 공식으로 구하세요.
obesity = (weight - standard_weight) / standard_weight * 100

# 값의 범위에 따라서 비만도 측정치가
# 다음의 항목들 중 하나의 문장으로 출력되도록 조건문을 구성하세요.
if obesity <= 20:
    print("20% 이하 - 정상(안심)")
elif obesity > 20 and obesity <= 30:
    print("20% 초과, 30% 이하 - 경도비만(주의)")
elif obesity > 30 and obesity <= 50:
    print("30% 초과, 50% 이하 - 중등도 비만(위험)")
else:
    print("50% 초과 - 고도비만(매우위험)")
