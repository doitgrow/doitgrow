# -*- coding: utf-8 -*-

check_list = [True, False, False, True, False]
print(check_list)

for i in range(0, len(check_list)):
    check_list[i] = not check_list[i]

print(check_list)

print("-" * 30)

# 다른 풀이 방법
# -> 반복문에 리스트를 직접 설정하는 경우
#    원소를 바로 얻을 수 있지만 몇 번째 원소인지는 알 수 없다.
# -> 현재 위치를 검사하기 위한 별도의 변수가 필요함.
check_list = [True, False, False, True, False]
print(check_list)

p = 0
for item in check_list:
    check_list[p] = not item
    # 현재 위치를 의미하는 변수를 1증가 시킴
    p = p + 1

print(check_list)

print("-" * 30)



# 또 다른 풀이방법
# -> enumerate() 함수는 리스트의 인덱스와 원소를 함께 사용할 수 있도록 한다.
check_list = [True, False, False, True, False]
print(check_list)

for i, item in enumerate(check_list):
	check_list[i] = not item

print(check_list)






