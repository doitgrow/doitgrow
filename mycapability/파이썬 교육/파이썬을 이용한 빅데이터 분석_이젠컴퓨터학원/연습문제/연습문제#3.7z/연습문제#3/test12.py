# -*- coding: utf-8 -*-

cart = [
    {'price': 38000, 'qty': 6},
    {'price': 20000, 'qty': 4},
    {'price': 17900, 'qty': 3},
    {'price': 17900, 'qty': 5}
]

total = 0 	# 총 합계 금액을 저장할 변수
# 장바구니의 개별 상태를 출력하기 위한 문자열 템플릿
tpl = "{0}원 x {1}개 -> 총 {2}원"

# 장바구니의 원소들을 item에 저장하는 동안 반복
for item in cart:
    # 상품별 합계금액
    sum = item['price'] * item['qty']
    print(tpl.format(item['price'], item['qty'], sum))

    # 총 합계 구하기
    total = total + sum

# 결과출력
print("-" * 30)
tpl = "총 합계 금액 -> {0}원"
print(tpl.format(total))

