# -*- coding: utf-8 -*-

inventory = [
    {'price': 500, 'qty': 291},
    {'price': 320, 'qty': 586},
    {'price': 100, 'qty': 460},
    {'price': 120, 'qty': 558},
    {'price': 92, 'qty': 18},
    {'price': 30, 'qty': 72},
]

total = 0

for item in inventory:
    total += item['price'] * 0.9 * item['qty']

print("%0.1fG" % total)


