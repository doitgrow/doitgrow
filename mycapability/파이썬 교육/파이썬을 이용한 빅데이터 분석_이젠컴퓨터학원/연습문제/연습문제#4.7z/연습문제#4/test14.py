# -*- coding: utf-8 -*-

# 공배수의 합을 구하기 위한 변수
sum = 0

# i에 1~100까지 순차적으로 저장하는 반복문
for i in range(1, 101):
    # "두 값으로 동시에 나누어 떨어지는 수"라면?
    if i % 3 == 0 and i % 5 == 0:
        # 출력
        print(i)
        sum = sum + i

tpl = "공배수의 총 합: {0}"
print(tpl.format(sum))


