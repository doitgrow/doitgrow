# -*- coding: utf-8 -*-

for i in range(0, 5):
    star = ""

    for j in range(5-i, 0, -1):
        star = star + "*"

    print(star)
