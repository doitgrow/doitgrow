# -*- coding: utf-8 -*-

times = [7, 5, 5, 5, 5, 10, 7]
total = 0

for i in range(0, len(times)):
    if i < 4:
        total = total + times[i] * 4500
    else:
        total = total + times[i] * 5200

tpl = "일주일간의 총 급여는 {0}원 입니다."
print(tpl.format(total))

