# -*- coding: utf-8 -*-

def sum(x, y):
    return x+y

print( sum(100, 200) )


