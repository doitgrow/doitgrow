# -*- coding: utf-8 -*-

def gugu(level):
    tpl = "{0} x {1} = {2}"

    for i in range(1, 10):
        x = level * i
        print( tpl.format(level, i, x) )

gugu(3)
print("-" * 10)
gugu(5)


