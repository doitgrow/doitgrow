# -*- coding: utf-8 -*-

def print_point(point):
    tpl = "{0}: {1}"
    print(tpl.format("국어", point["kor"]))
    print(tpl.format("영어", point["eng"]))
    print(tpl.format("수학", point["math"]))

    avg = (point["kor"] + point["eng"] + point["math"])/3
    print("-" * 30)
    print(tpl.format("평균", avg))


my_point = {"kor": 98, "eng": 82, "math": 75}
print_point(my_point)


