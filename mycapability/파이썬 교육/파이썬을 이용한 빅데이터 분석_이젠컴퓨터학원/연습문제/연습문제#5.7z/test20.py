# -*- coding: utf-8 -*-

grade_dic = {
	'이름': ['철수', '영희', '민철', '수현', '호영'],
    '국어': [98, 88, 92, 63, 120],
    '영어': [76, 90, 70, 60, 50],
    '수학': [88, 62, 88, 31, 76],
    '과학': [64, 72, 45, 70, 88]
}

tpl = "{0},{1},{2},{3},{4}\n" 	# 한 줄에 대한 템플릿
keys = list(grade_dic.keys())   # 딕셔너리의 키를 리스트로 변환

p = ","
title = p.join(keys)  # keys리스트 사이에 쉼표를 넣어 문자열로 변환

with open("grade.csv", "w", encoding='euc-kr') as f:
    # 첫 줄에 각 항목의 제목 기록
    f.write(title + "\n")

    # 각 데이터를 한 줄씩 콤마로 구분하여 기록
    for i in range(0, len(grade_dic['이름'])):
        tmp = tpl.format(grade_dic['이름'][i], grade_dic['국어'][i],
        	             grade_dic['영어'][i], grade_dic['수학'][i],
        	             grade_dic['과학'][i])
        f.write( tmp )


