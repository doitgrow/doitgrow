# -*- coding: utf-8 -*-

# 모듈 참조
from print_df import print_df
from pandas import ExcelFile
from pandas import DataFrame
from matplotlib import pyplot
import numpy

#---------------------------------------------------------
# 데이터 수집
#---------------------------------------------------------
# 엑셀파일 읽기
xls_file = ExcelFile('data/mpg.xlsx')

# 엑셀의 sheet 이름들 중에서 0번째 sheet를 dataframe으로 변환
df = xls_file.parse(xls_file.sheet_names[0])
print_df(df.head())

#---------------------------------------------------------
# 데이터 정제
#---------------------------------------------------------
# 결측치 여부 확인
empty_sum = df.isnull().sum()
print_df(empty_sum)


#---------------------------------------------------------
# 데이터 전처리
#---------------------------------------------------------
# 평균연비 합격을 의미하는 '연비테스트'컬럼을 mpg 데이터에 추가
# 평균연비 20이상이면 '합격', 그렇지 않으면 '불합격'
# 도시연비, 고속도로 연비를 활용하여 평균연비 데이터 avg을 mpg 데이터에 추가
df['연비테스트'] = numpy.where((df['cty'] + df['hwy']) / 2 >= 20, '합격', '불합격')
print_df(df.head(10))

# 각 값별로 수량을 카운트하여 새로운 데이터 프레임 생성
count = df['연비테스트'].value_counts()
count_df = DataFrame(count)
print_df(count_df)


#---------------------------------------------------
# 데이터 시각화
#---------------------------------------------------
# 그래프 만들기
pyplot.rcParams["font.family"] = 'NanumGothic'
pyplot.rcParams["font.size"] = 14
pyplot.rcParams["figure.figsize"] = (10, 10)

# 전체 컬럼에 대한 시각화
count_df['연비테스트'].plot.pie(autopct='%0.1f%%')
pyplot.grid()
pyplot.title("연비테스트 합격 비율")
pyplot.savefig('test.png', dpi=200)
pyplot.show()
pyplot.close()













